package com.jdbc.controller;

import java.util.List;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.jdbc.employeeDao.*;
import com.jdbc.model.*;

@Controller
public class Maincontroller {
	
	@Autowired
	employeeDao empDao;
	
	
	@Autowired
	Employee emp;
	
	String msg;
	
	@RequestMapping("/Home")
	public String home(Model model)
	{
		model.addAttribute("Employee",emp);
		model.addAttribute("msg",msg);
		return "index";
	}
	@RequestMapping("verify")
	public String verify(@ModelAttribute("emp") Employee emp ,Model mv,HttpSession session)
	{
		Employee emp1= empDao.validateEmployee(emp);
		if(emp1!=null)
		{
			msg="Login Sucessfully";
			session.setAttribute("emp",emp.getEmpName());
			System.out.println("Login Sucessfully");
			return "redirect:/getAll";
			
		}
		else
		{
			System.out.println("Login Failed");
			msg="Login Failed";
			return "redirect:/Home";
					
		}
		
	}
	@RequestMapping("/registration")
	public String registration(Model model)
	{
		model.addAttribute("emp",emp);
		return "registration";
	}
	@RequestMapping("Submitform")
	public ModelAndView saveEmployee(@ModelAttribute("emp") Employee emp,ModelAndView mv) 
	{
		empDao.addEmployee(emp);
		mv.addObject("msg", "Employee Added Sucessfully");
		mv.setViewName("registration");
		
		return mv;
	}
	@RequestMapping("getAll")
	public ModelAndView getAllEmployee(ModelAndView mv )
	{
		List<Employee> empList = empDao.getAllEmployee();
		mv.addObject("empList", empList);
		mv.setViewName("viewEmployee");
		return mv;
	}
	
	@RequestMapping("getEmployeeForm")
	public String getEmployeeForm()
	{
		return "getEmployee";
	}
	@RequestMapping("getById")
	public ModelAndView getById(@RequestParam("id") int id, ModelAndView mv)
	{
		Employee emp=empDao.getEmployeeById(id);
		mv.addObject("emp",emp);
		mv.setViewName("showEmployee");
		return mv;
	}
	
	@RequestMapping("updateemployee/{id}")
	
	public String getUpdateEmployee(@PathVariable int id,Model m)
	{
	
		Employee emp=empDao.getEmployeeById(id);
		System.out.println("In Controller" +emp);
		m.addAttribute("emp",emp);
		return "updateEmployee";
	}
		
		
	
	
	@RequestMapping("saveUpdate")
	public String saveUpdate(@ModelAttribute("emp") Employee emp)
   {
	 empDao.updateEmployee(emp);
	 return "redirect:/getAll";
   }
	@RequestMapping("deleteemployee/{id}")
	public String deleteEmployee(@PathVariable int id)
	{
		empDao.deleteEmployee(id);
		return "redirect:/getAll";
	}

}
