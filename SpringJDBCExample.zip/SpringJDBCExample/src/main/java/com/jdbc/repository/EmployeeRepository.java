package com.jdbc.repository;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.jdbc.model.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Integer>{
	@Query("Select e from Employee e where e.id=(:id) and e.password=(:password)")
	Employee findByLoginData(int id,String password);
	


}
