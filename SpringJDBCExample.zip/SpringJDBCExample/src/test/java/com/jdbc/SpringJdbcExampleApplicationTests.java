package com.jdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJdbcExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
